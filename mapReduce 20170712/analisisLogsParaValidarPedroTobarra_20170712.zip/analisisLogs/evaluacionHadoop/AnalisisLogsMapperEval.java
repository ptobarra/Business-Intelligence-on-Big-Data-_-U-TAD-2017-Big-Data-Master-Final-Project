package org.sourygna;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class AnalisisLogsMapper extends Mapper<Text, Text, Text, Text> {
	
	Text outKey = new Text();   //la MapOutputKey sera un Text tipo "[22/11/2014-18]	"donde 22 es el dia, 11 el mes, 2014 el año y 18 la hora a la que el proceso produjo el evento	
  	Text outValue = new Text();	//el MapOutputValue sera un Text tipo "Process:" donde Process es el nombre del proceso que produjo el evento q puede incluir el [PID] entre corchetes
  	  		
  	protected void map(Text notUsed, Text line, Context context) throws IOException ,InterruptedException {
  		
  		String[] row = line.toString().split(" "); //separamos la linea por espacios y cada palabra (String) será un elemento de row
 		  		
  		String dayStr = row[0];						//el String row[0] sera el dia
  		String hourCompleteStr = row[1];			//el String row[1] sera la hora completa en formato "hour:min:sec"; por ejemplo "21:27:51"  		
  		String processStr = row[3];					//el String row[3] es el nombre del proceso  		
  		
  		String[] hourCompleteArrayStr = hourCompleteStr.split(":");	//separamos el String de la hora completa por el caracter ":" en hora, minuto y segundo
  		String hourStr = hourCompleteArrayStr[0];					//nos cogemos la hora que es hourCompleteArrayStr[0] 
  		
  		String dayMonthYearHourStr = "[ "+ dayStr +"/11/2014-" + hourStr + " ]" + "\t";	//construimos la llave de la dupla de salida del Mapper en String
  		
  		outKey.set(dayMonthYearHourStr);
  		outValue.set(processStr);  	
  		
  		context.write(outKey, outValue);	//emitimos la dupla de salida
  	}	
}