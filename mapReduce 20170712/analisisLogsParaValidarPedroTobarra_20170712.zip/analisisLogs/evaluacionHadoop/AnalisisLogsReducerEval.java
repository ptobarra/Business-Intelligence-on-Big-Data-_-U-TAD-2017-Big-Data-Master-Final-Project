package org.sourygna;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class AnalisisLogsReducer extends Reducer<Text, Text, Text, Text>  {
	
	Text outKey = new Text();   //la ReduceOutputKey sera un Text tipo "[22/11/2014-18]	"donde 22 es el dia, 11 el mes, 2014 el año y 18 la hora a la que el proceso produjo el evento
  	Text outValue = new Text();	//el ReduceOutputValue sera un Text tipo "Process1:XX, Process2:YY, Process3:ZZ, ..."
  	//donde ProcessX es el nombre del proceso que produjo el evento q puede incluir el [PID] entre corchetes; y XX, YY, ZZ son el numero de apariciones de cada proceso 
	
	protected void reduce(Text dayMonthYearHourStr, Iterable<Text> ProcessList, Context context) throws IOException ,InterruptedException {
		StringBuilder lineStringBuilder = new StringBuilder();
		
		for (Text ProcessName : ProcessList) {		//con este for construimos un StringBuilder con los nombres y las apariciones de todos los procesos separados por comas ","
			lineStringBuilder.append(ProcessName).append(","); 			
		}
		
		String[] lineArrayString = lineStringBuilder.toString().split(","); 
		//convertimos el StringBuilder en un String y luego asignamos los nombres de los procesos separados por "," a un array de String donde cada elemento del arrays es el nombre de un proceso
		
		int eventCounter;	//variable que utilizaremos para contar el numero de eventos que produce cada proceso
		String processEventsStr = new String(); //usaremos este String para construir el value de la dupla de salida del reducer que sera la lista de procesos con sus apariciones
		processEventsStr = " ";	//inicializo el valor del String con un caracter " "
		
		for (int i=0; i<=lineArrayString.length-2; i++) {	//para contar apariciones para el 1er elemento nos paramos en el penultimo elemento de lineArrayString			
			
			if (lineArrayString[i] != "alreadyCounted") { //usamos el String "alreadyCounted" para descartar y marcar las posiciones de lineArrayString ya contadas
				
				eventCounter=1;	//en cada iteracion eventCounter al menos valdrá 1 ya que el cada proceso al menos genera el evento referenciado por lineArrayString[i]
				
				for (int j=i+1; j<=lineArrayString.length-1; j++) {	//para contar apariciones para el 2o elemento nos paramos en el ultimo elemento de lineArrayString
					
					if (lineArrayString[i] == lineArrayString[j]) { 
						eventCounter+=1;
						lineArrayString[j]= "alreadyCounted"; //usamos el String "alreadyCounted" para marcar las posisiones de lineArrayString ya contadas					
					}				
				}
				
				processEventsStr = processEventsStr + lineArrayString[i] + eventCounter + ", "; //añadimos a processEvents el proceso que aparecio con su numero de apariciones				
			}			
		}
		
		outKey.set(dayMonthYearHourStr);	//asignamos el String dayMonthYearHourStr al Text outKey que será la llave de la dupla de salida del reducer
  		outValue.set(processEventsStr);		//asignamos el String processEventsStr al Text outValue que será el value de la dupla de salida del reducer
		
		context.write(outKey, outValue); 
		// emitimos la dupla de salida que será del tipo:
		// ("[22/11/2014-18]	","Process1:XX, Process2:YY, Process3:ZZ, ")
		// para que la linea que al final saquemos por los ficheros de salida sea:
		// [22/11/2014-18]	Process1:XX, Process2:YY, Process3:ZZ, 
		}			
	}